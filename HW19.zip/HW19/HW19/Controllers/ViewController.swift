//
//  ViewController.swift
//  HW19
//
//  Created by Дмитрий Цветков on 30.10.2022.
//

import UIKit

class ViewController: UIViewController {

    var myCollectionView: UICollectionView?
    
    var helper = Helper()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setCollectView()
    }


    func setCollectView(){
        
        var layout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 20, left: 20, bottom: 20, right: 20)
        layout.itemSize = CGSize(width: 100, height: 100)
        layout.minimumLineSpacing = 6

        myCollectionView = UICollectionView(frame: self.view.frame, collectionViewLayout: layout)
        
        myCollectionView?.backgroundColor = .black
        
        myCollectionView?.delegate = self.helper
        myCollectionView?.dataSource = self.helper
        
        myCollectionView?.register(MyCollectionViewCell.self, forCellWithReuseIdentifier: helper.identifier)
        
        view.addSubview(myCollectionView ?? UICollectionView())
          
    }
}



