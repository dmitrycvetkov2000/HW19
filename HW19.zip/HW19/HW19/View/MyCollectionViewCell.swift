//
//  MyCollectionViewCell.swift
//  HW19
//
//  Created by Дмитрий Цветков on 30.10.2022.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    
    var labelForName = UILabel()
    var labelForNumber = UILabel()
    var image = UIImageView()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        
        self.addSubview(labelForName)
        self.addSubview(labelForNumber)
        self.addSubview(image)
        
        setConstrainsForNumberLabel()
        setConstrainsForNameLabel()
        setConstrainsForImage()
        
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    func setLabelForName(name: String) {
        labelForName.text = name
        labelForName.adjustsFontSizeToFitWidth = true
        labelForName.textAlignment = .left
    }
    func setLabelForNumber(number: String) {
        labelForNumber.text = number
    }
    func setImage(image: String) {
        self.image.image = UIImage(named: image)
        self.image.contentMode = .scaleAspectFit
    }

    
    func setConstrainsForNumberLabel() {
        labelForNumber.translatesAutoresizingMaskIntoConstraints = false
        
        labelForNumber.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 0).isActive = true
        labelForNumber.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: 0).isActive = true
        labelForNumber.heightAnchor.constraint(equalToConstant: 20).isActive = true
        labelForNumber.widthAnchor.constraint(equalToConstant: 22).isActive = true
    }
    
    func setConstrainsForNameLabel() {
        labelForName.translatesAutoresizingMaskIntoConstraints = false
        
        labelForName.leftAnchor.constraint(equalTo: labelForNumber.rightAnchor, constant: 6).isActive = true
        labelForName.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: 0).isActive = true
        labelForName.heightAnchor.constraint(equalToConstant: 20).isActive = true
        labelForName.rightAnchor.constraint(equalTo: self.rightAnchor, constant: 0).isActive = true
    }
    
    func setConstrainsForImage() {
        image.translatesAutoresizingMaskIntoConstraints = false
        
        image.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 0).isActive = true
        image.bottomAnchor.constraint(equalTo: labelForName.topAnchor, constant: 0).isActive = true
        image.topAnchor.constraint(equalTo: self.topAnchor, constant: 0).isActive = true
        image.rightAnchor.constraint(equalTo: self.rightAnchor, constant: 0).isActive = true
    }
    
}
